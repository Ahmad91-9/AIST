"""Tkinter view components."""


