import os
import json
from typing import Callable, Dict, Any

from PySide6 import QtCore, QtWidgets

from app.state import AppState


class FormPage(QtWidgets.QWidget):
    """Input form for property features."""

    def __init__(self, state: AppState, on_submit: Callable[[Dict[str, Any]], None]):
        super().__init__()
        self.state = state
        self.on_submit = on_submit
        self.inputs: Dict[str, QtWidgets.QWidget] = {}
        self.locations = self._get_available_locations()
        self._build()
    
    def _get_available_locations(self) -> list:
        """Load available locations from rules.json or use defaults."""
        default_locations = [
            "university road",
            "aziz bhatti town",
            "satellite town",
            "model town",
            "wapda town"
        ]
        
        rules_path = "rules.json"
        if os.path.exists(rules_path):
            try:
                with open(rules_path, "r", encoding="utf-8") as f:
                    rules = json.load(f)
                    # Try to get locations from rules.json
                    if "locations" in rules:
                        locations = [loc for loc in rules["locations"].keys() if loc != "default"]
                        if locations:
                            return sorted(locations)
                    # Fallback to location_rates if locations not found
                    elif "location_rates" in rules:
                        locations = [loc for loc in rules["location_rates"].keys() if loc != "default"]
                        if locations:
                            return sorted(locations)
            except Exception:
                pass
        
        return sorted(default_locations)

    def _build(self):
        # Ensure high-contrast form visuals
        self.setStyleSheet("background: #ffffff; color: #000000;")
        self.labels: Dict[str, QtWidgets.QLabel] = {}

        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(16, 16, 16, 16)
        outer.setSpacing(12)

        heading = QtWidgets.QLabel("Property Details")
        heading.setObjectName("title")
        outer.addWidget(heading)

        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        outer.addWidget(scroll, 1)

        container = QtWidgets.QWidget()
        scroll.setWidget(container)

        layout = QtWidgets.QGridLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setHorizontalSpacing(18)
        layout.setVerticalSpacing(14)

        form = QtWidgets.QFormLayout()
        form.setLabelAlignment(QtCore.Qt.AlignRight)
        form.setFormAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignTop)
        form.setHorizontalSpacing(14)
        form.setVerticalSpacing(10)

        def add_line(label: str, key: str, default: str = "", placeholder: str = ""):
            edit = QtWidgets.QLineEdit(str(default))
            if placeholder:
                edit.setPlaceholderText(placeholder)
            lbl = QtWidgets.QLabel(label)
            form.addRow(lbl, edit)
            self.inputs[key] = edit
            self.labels[key] = lbl

        def add_combo(label: str, key: str, values, default: str):
            combo = QtWidgets.QComboBox()
            combo.addItems(values)
            if default in values:
                combo.setCurrentText(default)
            lbl = QtWidgets.QLabel(label)
            form.addRow(lbl, combo)
            self.inputs[key] = combo
            self.labels[key] = lbl

        # Location dropdown
        location_default = self.state.last_input.get("location", "wapda town").lower()
        if location_default not in self.locations:
            location_default = self.locations[0] if self.locations else "wapda town"
        add_combo("Location", "location", self.locations, location_default)
        self.property_combo = QtWidgets.QComboBox()
        for val in ["house", "flat", "plot"]:
            self.property_combo.addItem(val)
        if self.state.last_input.get("property_type", "house") in ["house", "flat", "plot"]:
            self.property_combo.setCurrentText(self.state.last_input.get("property_type", "house"))
        lbl_prop = QtWidgets.QLabel("Property type")
        form.addRow(lbl_prop, self.property_combo)
        self.labels["property_type"] = lbl_prop
        info = QtWidgets.QLabel("For plots: enter length & width to calculate area. Flats prioritize floor/amenities.")
        info.setStyleSheet("color: #475467; font-size: 10pt;")
        info.setWordWrap(True)
        form.addRow("", info)
        self.inputs["property_type"] = self.property_combo
        
        # Area field for house/flat
        add_line("Area (sq ft)", "area", self.state.last_input.get("area", "2000"), "e.g., 2250")
        
        # Length and Width fields for plots
        add_line("Length (ft)", "length", self.state.last_input.get("length", ""), "e.g., 60")
        add_line("Width (ft)", "width", self.state.last_input.get("width", ""), "e.g., 40")
        
        add_line("Bedrooms", "bedrooms", self.state.last_input.get("bedrooms", "3"))
        add_line("Bathrooms", "bathrooms", self.state.last_input.get("bathrooms", "2"))
        add_line("Age (years)", "age", self.state.last_input.get("age", "5"))
        add_line("Parking (slots)", "parking", self.state.last_input.get("parking", "1"))
        add_line("Floor (for flats)", "floor", self.state.last_input.get("floor", "0"))
        
        # Plot-specific fields merged into main form
        def add_check(label: str, key: str, default: bool = False, tooltip: str = ""):
            chk = QtWidgets.QCheckBox(label)
            chk.setChecked(default)
            if tooltip:
                chk.setToolTip(tooltip)
            lbl = QtWidgets.QLabel("")
            form.addRow(lbl, chk)
            self.inputs[key] = chk
            self.labels[key] = lbl
        
        add_check("Corner plot", "corner", bool(self.state.last_input.get("corner", False)), "Corner plots often command a premium")
        add_check("Facing park", "facing_park", bool(self.state.last_input.get("facing_park", False)), "Facing green belt / park")
        add_check("Main boulevard", "main_boulevard", bool(self.state.last_input.get("main_boulevard", False)), "On or near main boulevard")
        add_check("Dead end", "dead_end", bool(self.state.last_input.get("dead_end", False)), "Cul-de-sac / dead-end street")
        
        add_line("Front width (ft)", "front_width", self.state.last_input.get("front_width", ""), "e.g., 40")
        add_line("Depth (ft)", "depth", self.state.last_input.get("depth", ""), "e.g., 60")
        add_line(
            "Nearby commercial dist (m)",
            "nearby_commercial_distance_m",
            self.state.last_input.get("nearby_commercial_distance_m", ""),
            "Distance to closest commercial area",
        )
        
        add_line("Amenities score (1-10)", "amenities", self.state.last_input.get("amenities", "7"))
        add_line("Demand score (1-10)", "demand_score", self.state.last_input.get("demand_score", "6"))
        add_line("Development score (1-10)", "development_score", self.state.last_input.get("development_score", "6"))
        add_line("Crime score (1-10)", "crime_score", self.state.last_input.get("crime_score", "3"))
        add_line("Legal score (1 = clean)", "legal_score", self.state.last_input.get("legal_score", "1"))

        layout.addLayout(form, 0, 0, 1, 1)

        # Action button row
        action_row = QtWidgets.QHBoxLayout()
        action_row.addStretch(1)
        btn = QtWidgets.QPushButton("Evaluate")
        btn.setFixedWidth(170)
        btn.clicked.connect(self._handle_submit)
        action_row.addWidget(btn)
        outer.addLayout(action_row)

        # Apply initial field masking based on property type
        self.property_combo.currentTextChanged.connect(self._on_property_type_change)
        self._on_property_type_change(self.property_combo.currentText())

    def _handle_submit(self):
        payload = {k: self._get_value(widget) for k, widget in self.inputs.items()}
        cleaned = self._normalize(payload)
        self.state.last_input = cleaned
        self.on_submit(cleaned)

    @staticmethod
    def _get_value(widget: QtWidgets.QWidget):
        if isinstance(widget, QtWidgets.QLineEdit):
            return widget.text()
        if isinstance(widget, QtWidgets.QComboBox):
            return widget.currentText()
        if isinstance(widget, QtWidgets.QCheckBox):
            return widget.isChecked()
        return None

    def _normalize(self, raw: Dict[str, Any]) -> Dict[str, Any]:
        """Cast numeric inputs; leave blanks empty for optional fields."""

        def as_float(val: Any):
            if val in ("", None):
                return ""
            try:
                return float(val)
            except Exception:
                return ""

        def as_int(val: Any):
            if val in ("", None):
                return 0
            try:
                return int(float(val))
            except Exception:
                return 0

        cleaned = dict(raw)
        property_type = cleaned.get("property_type", "house").lower()
        
        # For plots: calculate area from length * width
        if property_type == "plot":
            length_val = as_float(raw.get("length", ""))
            width_val = as_float(raw.get("width", ""))
            if length_val and width_val:
                cleaned["area"] = length_val * width_val
            else:
                cleaned["area"] = 0
        else:
            # For house/flat: use direct area input
            cleaned["area"] = as_float(raw.get("area"))
        
        cleaned["bedrooms"] = as_int(raw.get("bedrooms"))
        cleaned["bathrooms"] = as_int(raw.get("bathrooms"))
        cleaned["age"] = as_int(raw.get("age"))
        cleaned["parking"] = as_int(raw.get("parking"))
        cleaned["floor"] = as_int(raw.get("floor"))
        cleaned["amenities"] = as_float(raw.get("amenities"))
        cleaned["demand_score"] = as_float(raw.get("demand_score"))
        cleaned["development_score"] = as_float(raw.get("development_score"))
        cleaned["crime_score"] = as_float(raw.get("crime_score"))
        cleaned["legal_score"] = as_float(raw.get("legal_score"))

        def as_float_optional(val: Any):
            if val in ("", None):
                return None
            try:
                return float(val)
            except Exception:
                return None

        cleaned["front_width"] = as_float_optional(raw.get("front_width"))
        cleaned["depth"] = as_float_optional(raw.get("depth"))
        cleaned["nearby_commercial_distance_m"] = as_float_optional(raw.get("nearby_commercial_distance_m"))
        return cleaned

    def _on_property_type_change(self, value: str):
        """Show/hide relevant fields based on property type."""
        value = value.lower()
        house_flat = ["bedrooms", "bathrooms", "age", "parking"]
        flat_only = ["floor"]
        plot_only = [
            "length",
            "width",
            "corner",
            "facing_park",
            "main_boulevard",
            "dead_end",
            "front_width",
            "depth",
            "nearby_commercial_distance_m",
        ]

        if value == "plot":
            # Hide area (calculated from length * width), hide house/flat fields, show plot fields
            self._set_field_visible("area", False)
            for key in ["length", "width"]:
                self._set_field_visible(key, True)
            for key in house_flat + flat_only:
                self._set_field_visible(key, False)
                self._set_field_value(key, "")
            for key in plot_only[2:]:  # Skip length/width, already handled
                self._set_field_visible(key, True)
        elif value == "flat":
            # Show area, hide length/width, show house/flat fields + floor, hide plot specifics
            self._set_field_visible("area", True)
            for key in ["length", "width"]:
                self._set_field_visible(key, False)
            for key in house_flat + flat_only:
                self._set_field_visible(key, True)
            for key in plot_only[2:]:  # Skip length/width, hide all plot checkboxes/inputs
                self._set_field_visible(key, False)
        else:  # house
            # Show area, hide length/width, show house fields (no floor), hide plot specifics
            self._set_field_visible("area", True)
            for key in ["length", "width"]:
                self._set_field_visible(key, False)
            for key in house_flat:
                self._set_field_visible(key, True)
            for key in flat_only:
                self._set_field_visible(key, False)
            for key in plot_only[2:]:  # Skip length/width, hide all plot checkboxes/inputs
                self._set_field_visible(key, False)

    def _set_field_enabled(self, key: str, enable: bool):
        widget = self.inputs.get(key)
        if widget:
            widget.setEnabled(enable)

    def _set_field_value(self, key: str, val: Any):
        widget = self.inputs.get(key)
        if isinstance(widget, QtWidgets.QLineEdit):
            widget.setText(str(val))
        if isinstance(widget, QtWidgets.QCheckBox):
            widget.setChecked(bool(val))

    def _set_field_visible(self, key: str, visible: bool):
        widget = self.inputs.get(key)
        label = self.labels.get(key)
        if widget:
            widget.setVisible(visible)
        if label:
            label.setVisible(visible)


