from typing import Dict, Any

from PySide6 import QtCore, QtWidgets

from app.state import AppState


class ReportPage(QtWidgets.QWidget):
    """Displays the result of the expert system."""

    def __init__(self, state: AppState):
        super().__init__()
        self.state = state
        # High-contrast: black text everywhere in this page
        self.setStyleSheet(
            """
            QWidget { color: #000000; }
            QGroupBox { color: #000000; }
            QLabel { color: #000000; }
            QPlainTextEdit, QTableWidget { color: #000000; }
            """
        )
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        header = QtWidgets.QLabel("Evaluation Report")
        header.setObjectName("title")
        layout.addWidget(header)

        sub = QtWidgets.QLabel("Key financials, adjustments, and reasoning trace.")
        sub.setObjectName("subtitle")
        layout.addWidget(sub)

        # Stat cards (single row, roomy)
        cards = QtWidgets.QHBoxLayout()
        cards.setSpacing(12)
        price_card, self.price_label = self._stat_card("Final price", "—", minimum_width=210)
        rent_card, self.rent_label = self._stat_card("Rent (monthly)", "—", minimum_width=210)
        roi_card, self.roi_label = self._stat_card("ROI", "—", minimum_width=180)
        risk_card, self.risk_label = self._stat_card("Risk", "—", minimum_width=140)
        cards.addWidget(price_card, 1)
        cards.addWidget(rent_card, 1)
        cards.addWidget(roi_card, 1)
        cards.addWidget(risk_card, 1)
        layout.addLayout(cards)

        adjustments_box = QtWidgets.QGroupBox("Adjustments breakdown")
        adjustments_box.setStyleSheet(
            "QGroupBox { font-weight: 700; border: 1px solid #e1e4eb; border-radius: 10px; margin-top: 8px; padding: 10px 10px 4px 10px; }"
        )
        box_layout = QtWidgets.QVBoxLayout(adjustments_box)
        box_layout.setContentsMargins(4, 8, 4, 8)
        box_layout.setSpacing(6)

        self.table = QtWidgets.QTableWidget(0, 2)
        self.table.setHorizontalHeaderLabels(["Adjustment", "Amount (Rs)"])
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QtWidgets.QTableWidget.NoEditTriggers)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.NoSelection)
        self.table.setMinimumHeight(220)
        self.table.setStyleSheet(
            "QTableWidget { border: 1px solid #e1e4eb; border-radius: 8px; }"
            "QTableWidget::item { padding: 6px; }"
            "QHeaderView::section { background: #f8fafc; font-weight: 700; }"
        )
        box_layout.addWidget(self.table)
        layout.addWidget(adjustments_box)

        # Forecast badges with breathing space
        forecasts = QtWidgets.QHBoxLayout()
        forecasts.setSpacing(10)
        self.forecast1 = self._pill("1-year forecast", "—")
        self.forecast3 = self._pill("3-year forecast", "—")
        forecasts.addWidget(self.forecast1)
        forecasts.addWidget(self.forecast3)
        forecasts.addStretch(1)
        layout.addLayout(forecasts)

        self.explainer = QtWidgets.QPlainTextEdit()
        self.explainer.setReadOnly(True)
        self.explainer.setPlaceholderText("Detailed reasoning will appear here.")
        self.explainer.setMinimumHeight(180)
        layout.addWidget(self.explainer)

    def update_report(self, result: Dict[str, Any]):
        if not result:
            return
        self.state.last_result = result
        prop_type = result.get("property_type", "").lower()
        self.price_label.setText(f"Rs {result['final_price']:,.0f}")
        if prop_type == "plot":
            self.rent_label.setText("N/A")
            self.roi_label.setText("N/A")
        else:
            self.rent_label.setText(f"Rs {result['rent_monthly']:,.0f}")
            self.roi_label.setText(f"{result['roi']*100:.2f}%")
        self.risk_label.setText(f"{result['risk_score']}")
        if result.get("forecast_1y_pct") is not None:
            self.forecast1.setText(f"1y: {result['forecast_1y_pct']*100:.2f}%")
        if result.get("forecast_3y_pct") is not None:
            self.forecast3.setText(f"3y: {result['forecast_3y_pct']*100:.2f}%")

        adjustments = result.get("adjustments", [])
        self.table.setRowCount(len(adjustments))
        for row, (reason, amt) in enumerate(adjustments):
            reason_item = QtWidgets.QTableWidgetItem(reason)
            amt_item = QtWidgets.QTableWidgetItem(f"{amt:,.0f}")
            amt_item.setTextAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
            reason_item.setTextAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
            self.table.setItem(row, 0, reason_item)
            self.table.setItem(row, 1, amt_item)

        self.explainer.clear()
        for line in result.get("explanation", []):
            self.explainer.appendPlainText(f"- {line}")

    def _stat_card(self, title: str, value: str, minimum_width: int = 180) -> tuple[QtWidgets.QFrame, QtWidgets.QLabel]:
        frame = QtWidgets.QFrame()
        frame.setStyleSheet(
            "QFrame { background: #fff; border: 1px solid #e1e4eb; border-radius: 10px; padding: 14px; color: #000; }"
        )
        frame.setMinimumWidth(minimum_width)
        v = QtWidgets.QVBoxLayout(frame)
        v.setSpacing(4)
        t = QtWidgets.QLabel(title)
        t.setStyleSheet("color: #000000; font-weight: 600;")
        val = QtWidgets.QLabel(value)
        val.setStyleSheet("font-size: 18px; font-weight: 700; color: #000000;")
        val.setWordWrap(True)
        v.addWidget(t)
        v.addWidget(val)
        return frame, val

    def _pill(self, label: str, value: str) -> QtWidgets.QLabel:
        pill = QtWidgets.QLabel(f"{label}: {value}")
        pill.setStyleSheet(
            "QLabel { background: #f2f2f2; color: #000000; padding: 6px 10px; border-radius: 14px; font-weight: 600; }"
        )
        return pill


