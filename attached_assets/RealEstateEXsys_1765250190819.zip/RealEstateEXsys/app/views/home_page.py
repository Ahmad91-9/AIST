from PySide6 import QtCore, QtWidgets


class HomePage(QtWidgets.QWidget):
    """Intro page with quick guidance."""

    def __init__(self):
        super().__init__()
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(12)

        hero = QtWidgets.QLabel("Real Estate Expert")
        hero.setObjectName("title")
        layout.addWidget(hero)

        subtitle = QtWidgets.QLabel(
            "Data-backed pricing, rent, ROI, risk, and growth forecasts in seconds."
        )
        subtitle.setObjectName("subtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        cards = QtWidgets.QHBoxLayout()
        cards.setSpacing(12)
        for title, body in [
            ("1. Enter details", "Fill location, size, and property attributes in the Form tab."),
            ("2. Evaluate", "Click Evaluate to combine rules with your trained ML models."),
            ("3. Review insights", "See price, rent, ROI, risk, and reasoning trace on the Report tab."),
        ]:
            card = self._info_card(title, body)
            cards.addWidget(card, 1)
        layout.addLayout(cards)

        tips = QtWidgets.QGroupBox("Pro tips")
        tips_layout = QtWidgets.QVBoxLayout(tips)
        tips_layout.setSpacing(6)
        for tip in [
            "Use the most specific location available for better base rates.",
            "Amenities, demand, and development scores strongly influence forecasts.",
            "For plots, front width / depth and positioning (corner, park-facing) matter.",
        ]:
            lbl = QtWidgets.QLabel(f"• {tip}")
            lbl.setWordWrap(True)
            tips_layout.addWidget(lbl)
        layout.addWidget(tips)
        layout.addStretch(1)

    def _info_card(self, title: str, body: str) -> QtWidgets.QFrame:
        card = QtWidgets.QFrame()
        card.setFrameShape(QtWidgets.QFrame.StyledPanel)
        card.setStyleSheet(
            "QFrame { background: #fff; border: 1px solid #e1e4eb; border-radius: 10px; padding: 12px; }"
        )
        v = QtWidgets.QVBoxLayout(card)
        v.setSpacing(6)
        h = QtWidgets.QHBoxLayout()
        dot = QtWidgets.QLabel("●")
        dot.setStyleSheet("color: #3b82f6; font-size: 12px;")
        h.addWidget(dot, alignment=QtCore.Qt.AlignTop)
        text_wrap = QtWidgets.QVBoxLayout()
        t = QtWidgets.QLabel(title)
        t.setStyleSheet("font-weight: 700; color: #0f172a;")
        b = QtWidgets.QLabel(body)
        b.setWordWrap(True)
        b.setStyleSheet("color: #475467;")
        text_wrap.addWidget(t)
        text_wrap.addWidget(b)
        h.addLayout(text_wrap)
        v.addLayout(h)
        return card


