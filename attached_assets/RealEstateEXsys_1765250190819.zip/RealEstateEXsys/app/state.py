from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass
class AppState:
    """Shared state between pages."""

    last_input: Dict[str, Any] = field(default_factory=dict)
    last_result: Optional[Dict[str, Any]] = None
    last_error: Optional[str] = None


