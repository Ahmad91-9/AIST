"""
GUI package for the RealEstate expert system.

Run with:
    python -m app.main
"""


