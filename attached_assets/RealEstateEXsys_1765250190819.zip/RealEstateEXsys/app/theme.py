import tkinter as tk
from tkinter import ttk


def configure_theme(root: tk.Tk):
    """Configure ttk styles for a cleaner look."""
    style = ttk.Style(root)
    # Use native theme if available
    preferred = "clam" if "clam" in style.theme_names() else style.theme_use()
    style.theme_use(preferred)

    style.configure(
        "TLabel",
        font=("Segoe UI", 10),
        padding=(2, 2),
    )
    style.configure(
        "Header.TLabel",
        font=("Segoe UI", 12, "bold"),
        padding=(4, 4),
    )
    style.configure(
        "TButton",
        font=("Segoe UI", 10, "bold"),
        padding=(8, 6),
    )
    style.configure(
        "Card.TFrame",
        relief="groove",
        borderwidth=1,
        padding=10,
    )


