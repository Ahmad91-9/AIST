from PySide6 import QtCore, QtWidgets

from app.expert_service import ExpertFacade
from app.state import AppState
from app.views.form_page import FormPage
from app.views.home_page import HomePage
from app.views.report_page import ReportPage


class MainWindow(QtWidgets.QMainWindow):
    """Main window hosting tabs for Home, Form, and Report."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Real Estate Expert System")
        self.resize(1100, 1100)
        self.state = AppState()
        self.facade = ExpertFacade()
        self._build_ui()

    def _build_ui(self):
        self._apply_styles()

        central = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(central)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        self.tabs = QtWidgets.QTabWidget()
        self.tabs.setTabPosition(QtWidgets.QTabWidget.North)

        self.home = HomePage()
        self.form = FormPage(self.state, self._handle_submit)
        self.report = ReportPage(self.state)

        self.tabs.addTab(self.home, "Home")
        self.tabs.addTab(self.form, "Form")
        self.tabs.addTab(self.report, "Report")

        layout.addWidget(self.tabs)

        self.status = QtWidgets.QStatusBar()
        self.setStatusBar(self.status)
        self.status.showMessage("Ready")

        self.setCentralWidget(central)

    def _handle_submit(self, payload):
        try:
            result = self.facade.evaluate(payload)
            self.report.update_report(result)
            self.status.showMessage("Evaluation completed")
            self.tabs.setCurrentWidget(self.report)
        except Exception as exc:
            self.state.last_error = str(exc)
            self.status.showMessage("Error")
            QtWidgets.QMessageBox.critical(self, "Evaluation failed", str(exc))

    def _apply_styles(self):
        """Lightweight, modern stylesheet for the entire app."""
        self.setStyleSheet(
            """
            QWidget { font-family: 'Segoe UI', 'Inter', system-ui; font-size: 11pt; }
            QMainWindow { background: #f6f7fb; }
            QTabWidget::pane { border: 1px solid #d9dce3; border-radius: 8px; background: #fff; }
            QTabBar::tab { background: #eef1f7; padding: 10px 18px; border-top-left-radius: 6px; border-top-right-radius: 6px; margin-right: 4px; }
            QTabBar::tab:selected { background: #fff; font-weight: 600; color: #1f3d7a; }
            QLabel#title { font-size: 20px; font-weight: 700; color: #1f3d7a; }
            QLabel#subtitle { font-size: 13px; color: #4a5568; }
            QGroupBox { border: 1px solid #e1e4eb; border-radius: 10px; margin-top: 10px; padding: 12px; font-weight: 600; background: #fff; }
            QGroupBox::title { subcontrol-origin: margin; left: 8px; top: -6px; background: transparent; padding: 0 6px; color: #1f3d7a; }
            QLineEdit, QComboBox, QPlainTextEdit { border: 1px solid #d9dce3; border-radius: 6px; padding: 6px 8px; background: #fff; }
            QLineEdit:focus, QComboBox:focus, QPlainTextEdit:focus { border: 1px solid #3b82f6; box-shadow: 0 0 0 2px rgba(59,130,246,0.15); }
            QPushButton { background: linear-gradient(135deg, #3b82f6, #2563eb); color: white; border: none; border-radius: 8px; padding: 10px 16px; font-weight: 600; }
            QPushButton:hover { background: linear-gradient(135deg, #2563eb, #1d4ed8); }
            QPushButton:disabled { background: #cbd5e1; color: #fff; }
            QTableWidget { background: #fff; border: 1px solid #e1e4eb; border-radius: 10px; }
            QHeaderView::section { background: #f1f5f9; padding: 8px; border: none; font-weight: 700; color: #1f2937; }
            QStatusBar { background: #f1f5f9; border: 1px solid #e1e4eb; }
            """
        )


def main():
    app = QtWidgets.QApplication([])
    QtCore.QCoreApplication.setApplicationName("Real Estate Expert System")
    window = MainWindow()
    window.show()
    app.exec()


if __name__ == "__main__":
    main()


