import os
from typing import Any, Dict

from EXsystem import Features, MLModelManager, RealEstateExpertSystem, load_rules_from_file


class ExpertFacade:
    """Thin wrapper around RealEstateExpertSystem for the GUI."""

    def __init__(self, rules_path: str = "rules.json"):
        if not os.path.exists(rules_path):
            # ensure default rules exist
            _ = load_rules_from_file(rules_path)
        self.rules_path = rules_path
        # Wire up ML models from the packaged Models directory
        model_paths = {
            "price": os.path.join("Models", "price_model.pkl"),
            "rent": os.path.join("Models", "rent_model.pkl"),
            "roi": os.path.join("Models", "roi_model.pkl"),
            "risk": os.path.join("Models", "risk_model.pkl"),
            "future_1y": os.path.join("Models", "future_price_1yr_model.pkl"),
            "future_3y": os.path.join("Models", "future_price_3yr_model.pkl"),
        }
        ml_manager = MLModelManager(model_paths)
        self.expert = RealEstateExpertSystem(
            rules=load_rules_from_file(rules_path), ml_manager=ml_manager
        )

    def evaluate(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Validate, run the expert system, and return the result dict."""
        features = self._payload_to_features(payload)
        return self.expert.evaluate_all(features)

    def _payload_to_features(self, payload: Dict[str, Any]) -> Features:
        """Convert raw form payload into the Features dataclass."""
        # Normalize property type to lower
        property_type = payload.get("property_type", "house").lower()

        # Optional booleans for plot inputs
        def to_bool(val: Any) -> bool:
            if isinstance(val, bool):
                return val
            if isinstance(val, str):
                return val.strip().lower() in {"yes", "true", "1", "y"}
            return bool(val)

        return Features(
            location=payload.get("location", "").strip(),
            area=float(payload.get("area", 0)),
            property_type=property_type,
            bedrooms=int(payload.get("bedrooms", 0)),
            bathrooms=int(payload.get("bathrooms", 0)),
            age=int(payload.get("age", 0)),
            parking=int(payload.get("parking", 0)),
            floor=int(payload.get("floor", 0)),
            amenities=float(payload.get("amenities", 5)),
            demand_score=float(payload.get("demand_score", 5)),
            development_score=float(payload.get("development_score", 5)),
            crime_score=float(payload.get("crime_score", 5)),
            legal_score=float(payload.get("legal_score", 1)),
            # Plot-specific (safe defaults)
            corner=to_bool(payload.get("corner", False)),
            facing_park=to_bool(payload.get("facing_park", False)),
            main_boulevard=to_bool(payload.get("main_boulevard", False)),
            dead_end=to_bool(payload.get("dead_end", False)),
            shape=payload.get("shape", "rectangular"),
            front_width=self._safe_optional_float(payload.get("front_width")),
            depth=self._safe_optional_float(payload.get("depth")),
            nearby_commercial_distance_m=self._safe_optional_float(
                payload.get("nearby_commercial_distance_m")
            ),
            # Additional optional values used by house/flat rules
            # Using getattr checks inside the engine, so we can pass conditionally
        )

    @staticmethod
    def _safe_optional_float(value: Any):
        if value in (None, "", "None"):
            return None
        try:
            return float(value)
        except Exception:
            return None


