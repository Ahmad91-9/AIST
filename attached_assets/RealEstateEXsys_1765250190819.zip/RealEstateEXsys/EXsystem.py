"""
real_estate_expert.py

Production-style expert system for real-estate valuation and analytics.

Features:
- Rule engine: loads rules from JSON and applies them by property type.
- Unified scoring engine: base price calculation, adjustments, rent, ROI, risk, forecast.
- ML integration placeholders: load .pkl or .pt models safely and use them if available.
- Clean, testable, class-based design.
- Example usage shows end-to-end flow.

Requirements:
- Python 3.8+
- Standard library only (pickle + json + typing + math).
- Optional: torch for loading .pt models. If torch is not installed, .pt models will not be loaded.
"""

import json
import math
import os
import pickle
try:
    import joblib
    JOBLIB_AVAILABLE = True
except Exception:
    JOBLIB_AVAILABLE = False
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Tuple

# Try to import torch for .pt support; handle gracefully if not installed.
try:
    import torch
    TORCH_AVAILABLE = True
except Exception:
    TORCH_AVAILABLE = False


# -------------------------
# Default rules JSON (industry-style)
# -------------------------
DEFAULT_RULES_JSON = {
    "location_rates": {
        # Standard rate (per sq ft) for subareas - can be extended or loaded from a DB
        # Use realistic numbers according to market; these are placeholders.
        "university road": 20000,
        "aziz bhatti town": 25000,
        "satellite town": 15000,
        "model town": 14000,
        "wapda town": 12000,
        "default": 10000
    },
    "location_tiers": {
        # Tier multipliers: usage in tier-based logic if needed
        "A": 1.20,
        "B": 1.00,
        "C": 0.90,
        "D": 0.80
    },
    "area_size_rules": [
        {"max": 1200, "multiplier": 1.05, "description": "small_area_premium"},
        {"min": 1200, "max": 3000, "multiplier": 1.00, "description": "standard_area"},
        {"min": 3000, "multiplier": 0.95, "description": "large_area_discount"}
    ],
    "common": {
        "amenities_max_effect": 0.07,
        "amenities_scale": 10.0
    },
    "house": {
        "standard_bedrooms": 3,
        "bedroom_extra_pct": 0.03,
        "bedroom_missing_pct": -0.02,
        "standard_bathrooms": 2,
        "bathroom_extra_pct": 0.02,
        "bathroom_missing_pct": -0.02,
        "condition": {
            "new_0_3": 0.10,
            "slightly_used_4_10": 0.03,
            "old_11_20": -0.08,
            "very_old_21_plus": -0.12
        },
        "construction_quality_per_point": 0.02,
        "parking": {
            "has_parking_pct": 0.03,
            "no_parking_pct": -0.03
        },
        "street_width": {
            "wide_percent": 0.05,
            "narrow_percent": -0.04,
            "wide_min_ft": 40,
            "narrow_max_ft": 20
        }
    },
    "flat": {
        "floor": {
            "ground_pct": 0.05,
            "1_4_pct": 0.0,
            "5_8_pct": -0.02,
            "9_plus_pct": -0.04
        },
        "building_age": {
            "0_5": 0.06,
            "6_15": 0.0,
            "16_25": -0.08,
            "25_plus": -0.12
        },
        "lift_available_pct": 0.04,
        "no_lift_high_floor_penalty": -0.08,
        "parking": {
            "dedicated_pct": 0.03,
            "shared_pct": 0.01,
            "none_pct": -0.03
        },
        "security_max_effect": 0.05
    },
    "plot": {
        "position": {
            "corner_pct": 0.10,
            "facing_park_pct": 0.08,
            "main_boulevard_pct": 0.12,
            "dead_end_pct": -0.05
        },
        "shape": {
            "rectangular_pct": 0.03,
            "odd_pct": -0.03
        },
        "front_depth_ratio_threshold": 0.5,
        "front_depth_penalty": -0.04,
        "soil": {
            "solid_pct": 0.03,
            "mixed_pct": 0.0,
            "soft_pct": -0.03
        },
        "nearby_commercial": {
            "within_200m_pct": 0.05,
            "too_close_50m_penalty": -0.04
        }
    },
    "rent": {
        "multipliers": {
            "house": 0.0065,
            "flat": 0.0075
        },
        "furnishing": {
            "fully": 0.25,
            "semi": 0.10,
            "none": 0.0
        }
    },
    "roi": {
        "classification": {
            "high": 0.07,
            "moderate": 0.05
        }
    },
    "risk": {
        # Weighted factors
        "weights": {
            "crime": 0.30,
            "legal": 0.30,
            "market_volatility": 0.20,
            "development": 0.20
        }
    },
    "forecast": {
        "growth_factors": {
            # More conservative defaults (max ~8-9% for extreme scores)
            "demand_score_weight_pct": 0.003,         # each demand score point -> 0.3%
            "development_score_weight_pct": 0.004,    # each development point -> 0.4%
            "market_trend_pct": 0.005                 # baseline market trend (can be tuned +/-)
        },
        "uncertainty_scale": 0.15   # reduce 3-year forecast by 15% to account for uncertainty
    }
}


# -------------------------
# Utility dataclasses and types
# -------------------------
@dataclass
class Features:
    """All inputs from GUI/API stored in a typed dataclass for validation."""
    location: str
    area: float
    property_type: str  # 'house' | 'flat' | 'plot'
    bedrooms: int = 0
    bathrooms: int = 0
    condition: str = "used"  # 'new', 'slightly_used', 'old', ...
    age: int = 0
    parking: int = 0
    floor: int = 0  # only for flats
    amenities: float = 3.0  # 1-10 scale in our design (but GUI used 1-5; we accept either)
    # Plot specific
    corner: bool = False
    facing_park: bool = False
    main_boulevard: bool = False
    dead_end: bool = False
    shape: str = "rectangular"  # 'rectangular' | 'odd'
    front_width: Optional[float] = None
    depth: Optional[float] = None
    soil: str = "mixed"  # 'solid', 'mixed', 'soft'
    nearby_commercial_distance_m: Optional[float] = None
    # Other meta
    demand_score: float = 5.0  # 1-10
    development_score: float = 5.0  # 1-10
    crime_score: float = 5.0  # 1-10
    legal_score: float = 1.0  # 1 = clean, higher means issues. We'll flip logic when needed.


# -------------------------
# ML Model Manager
# -------------------------
class MLModelManager:
    """
    Placeholder manager to load ML models and expose a simple API to predict:
      - price
      - rent
      - roi
      - risk
      - future_price

    Expectation for models:
    - Pickle models: expose .predict(X) where X is a 2D array or structured dict-like feature vector.
    - Torch models (.pt): expect user to wrap input vector and run model(input_tensor).cpu().numpy()

    This implementation does not execute complex transforms. It is a safe wrapper showing how to integrate.
    """

    def __init__(self, paths: Dict[str, Optional[str]] = None):
        """
        paths: dict with optional keys: 'price', 'rent', 'roi', 'risk', 'future'
               values are file paths to model files (.pkl or .pt)
        """
        self.paths = paths or {}
        self.models: Dict[str, Any] = {}
        self.load_models()

    def load_models(self):
        for key, path in (self.paths or {}).items():
            if not path:
                continue
            if not os.path.exists(path):
                print(f"[MLModelManager] Model file not found for '{key}': {path}")
                continue

            ext = os.path.splitext(path)[1].lower()
            try:
                if ext in [".pkl", ".joblib"]:
                    if JOBLIB_AVAILABLE:
                        self.models[key] = joblib.load(path)
                    else:
                        with open(path, "rb") as f:
                            self.models[key] = pickle.load(f)
                    print(f"[MLModelManager] Loaded pickle model for '{key}' from {path}")
                elif ext in [".pt", ".pth"]:
                    if not TORCH_AVAILABLE:
                        print(f"[MLModelManager] Torch not available. Can't load {path}.")
                        continue
                    self.models[key] = torch.load(path, map_location="cpu")
                    if hasattr(self.models[key], "eval"):
                        try:
                            self.models[key].eval()
                        except Exception:
                            pass
                    print(f"[MLModelManager] Loaded torch model for '{key}' from {path}")
                else:
                    print(f"[MLModelManager] Unsupported model extension '{ext}' for {path}")
            except Exception as e:
                print(f"[MLModelManager] Error loading model {path}: {e}")

    def predict(self, key: str, feature_vector: Dict[str, Any]) -> Optional[float]:
        """
        Simple prediction wrapper. The project should provide a consistent feature vector expected by the model.
        If no model loaded for key, returns None.
        """
        model = self.models.get(key)
        if not model:
            return None

        # Pickle scikit-style models:
        if hasattr(model, "predict"):
            try:
                import pandas as pd

                # Use DataFrame to preserve column names expected by the pipelines
                df = pd.DataFrame([feature_vector])
                return float(model.predict(df)[0])
            except Exception as e:
                print(f"[MLModelManager] Model predict error for {key}: {e}")
                return None

        # Torch model fallback: user must implement a wrapper in production
        if TORCH_AVAILABLE and isinstance(model, torch.nn.Module):
            try:
                import numpy as np
                arr = np.array(list(feature_vector.values()), dtype=float).reshape(1, -1)
                tensor = torch.from_numpy(arr).float()
                with torch.no_grad():
                    out = model(tensor)
                # if model returns tensor, convert to float
                if hasattr(out, "cpu"):
                    out = out.cpu().numpy()
                # Flatten and return first
                return float(out.flatten()[0])
            except Exception as e:
                print(f"[MLModelManager] Torch model predict error for {key}: {e}")
                return None

        print(f"[MLModelManager] Unknown model type for key {key}")
        return None


# -------------------------
# Rule Engine and Evaluator
# -------------------------
class RealEstateExpertSystem:
    """
    Core expert system. All heavy logic lives here.
    It reads rules from a JSON-like mapping and applies them against feature vectors.
    """
    def __init__(self, rules: Optional[Dict[str, Any]] = None, ml_manager: Optional[MLModelManager] = None):
        # Load rules (copy to avoid mutation)
        self.rules = rules.copy() if rules else DEFAULT_RULES_JSON.copy()
        # Ensure nested objects exist (defensive)
        self._ensure_defaults()
        self.ml = ml_manager or MLModelManager({})
        self.reset_state()

    def _ensure_defaults(self):
        # Merge defaults to avoid key errors if user provided partial rules
        # For brevity, assume rules are well-formed in this code path.
        pass

    def reset_state(self):
        self.features: Optional[Features] = None
        self.adjustments: List[Tuple[str, float]] = []
        self.base_price: float = 0.0
        self.final_price: float = 0.0
        self.base_rent: Optional[float] = None
        self.risk_score: Optional[float] = None
        self.forecast_1y: Optional[float] = None
        self.forecast_3y: Optional[float] = None
        self.roi_value: Optional[float] = None
        self.explanation: List[str] = []

    # -------------------------
    # Input handling
    # -------------------------
    def set_features(self, features: Features):
        """Set and validate features."""
        # Basic validation
        if features.area <= 0:
            raise ValueError("Area must be positive.")
        if features.property_type.lower() not in {"house", "flat", "plot"}:
            raise ValueError("property_type must be 'house', 'flat' or 'plot'.")
        if not (1 <= features.amenities <= 10):
            # accept 1-5 from earlier GUI by scaling, but normalize to 1-10 for internal rules
            if 1 <= features.amenities <= 5:
                features.amenities = features.amenities * 2
            else:
                raise ValueError("amenities must be in 1-10 (or 1-5 will be auto-scaled).")

        self.features = features
        self.reset_computed()

    def reset_computed(self):
        self.adjustments = []
        self.base_price = 0.0
        self.final_price = 0.0
        self.base_rent = None
        self.risk_score = None
        self.forecast_1y = None
        self.forecast_3y = None
        self.roi_value = None
        self.explanation = []

    # -------------------------
    # Base price calculation
    # -------------------------
    def determine_base_price(self):
        """Calculate base price as area * location_rate, with tier and area size adjustments."""
        assert self.features is not None, "Set features first."

        loc = self.features.location.lower()
        location_rates = self.rules.get("location_rates", {})
        base_rate = location_rates.get(loc, location_rates.get("default", 10000))
        # location tier logic can be applied here if subarea tier exists; omitted for simplicity

        # area size multiplier
        area_multiplier = 1.0
        area_rules = self.rules.get("area_size_rules", [])
        for rule in area_rules:
            if "min" in rule and "max" in rule:
                if rule["min"] <= self.features.area <= rule["max"]:
                    area_multiplier = rule["multiplier"]
                    break
            elif "max" in rule:
                if self.features.area <= rule["max"]:
                    area_multiplier = rule["multiplier"]
                    break
            elif "min" in rule:
                if self.features.area >= rule["min"]:
                    area_multiplier = rule["multiplier"]
                    break

        rule_base = self.features.area * base_rate * area_multiplier
        self.base_price = rule_base
        self.explanation.append(
            f"Base price (rules): area {self.features.area} * rate {base_rate:,} * area_mult {area_multiplier:.3f}"
        )

        # Try ML price model override for non-plot types only
        if self.features.property_type.lower() != "plot":
            ml_price = self.ml.predict("price", self._features_for_model("price"))
            if ml_price is not None:
                self.base_price = ml_price
                self.explanation.append(
                    f"Base price overridden by ML price model: {ml_price:,.0f} (rule-based {rule_base:,.0f})"
                )

        return self.base_price

    # -------------------------
    # Apply rules by property type
    # -------------------------
    def apply_rules(self):
        """Apply type-specific rules and common rules to compute adjustments."""
        assert self.features is not None, "Set features first."
        if self.base_price <= 0:
            self.determine_base_price()

        bp = self.base_price
        prop_type = self.features.property_type.lower()

        # Common: Amenities
        common = self.rules.get("common", {})
        amenities_max = common.get("amenities_max_effect", 0.07)
        amenities_scale = common.get("amenities_scale", 10.0)
        amenities_factor = (self.features.amenities / amenities_scale) * amenities_max
        self.adjustments.append(("Amenities score adjustment", bp * amenities_factor))
        self.explanation.append(f"Amenities factor: {amenities_factor:.4f} -> {bp * amenities_factor:,.0f}")

        # Dispatch to specific rule sets
        if prop_type == "house":
            self._apply_house_rules(bp)
        elif prop_type == "flat":
            self._apply_flat_rules(bp)
        elif prop_type == "plot":
            self._apply_plot_rules(bp)
        else:
            # unknown type: no further adjustments
            self.explanation.append("Unknown property type; no specific adjustments applied.")

    def _apply_house_rules(self, bp: float):
        r = self.rules.get("house", {})
        # Bedrooms
        std_bed = r.get("standard_bedrooms", 3)
        if self.features.bedrooms > std_bed:
            extra = self.features.bedrooms - std_bed
            amount = bp * r.get("bedroom_extra_pct", 0.03) * extra
            self.adjustments.append((f"Extra bedrooms ({extra})", amount))
            self.explanation.append(f"Bed bonus: {extra} * {r.get('bedroom_extra_pct',0.03)*100:.2f}% of base")
        elif self.features.bedrooms < std_bed:
            missing = std_bed - self.features.bedrooms
            amount = bp * r.get("bedroom_missing_pct", -0.02) * missing
            self.adjustments.append((f"Missing bedrooms ({missing})", amount))
            self.explanation.append(f"Bed penalty: {missing} * {r.get('bedroom_missing_pct',-0.02)*100:.2f}% of base")

        # Bathrooms
        std_bath = r.get("standard_bathrooms", 2)
        if self.features.bathrooms > std_bath:
            extra = self.features.bathrooms - std_bath
            amount = bp * r.get("bathroom_extra_pct", 0.02) * extra
            self.adjustments.append((f"Extra bathrooms ({extra})", amount))
            self.explanation.append(f"Bath bonus: {extra} * {r.get('bathroom_extra_pct',0.02)*100:.2f}% of base")
        elif self.features.bathrooms < std_bath:
            missing = std_bath - self.features.bathrooms
            amount = bp * r.get("bathroom_missing_pct", -0.02) * missing
            self.adjustments.append((f"Missing bathrooms ({missing})", amount))
            self.explanation.append(f"Bath penalty: {missing} * {r.get('bathroom_missing_pct',-0.02)*100:.2f}% of base")

        # Condition and age
        cond_table = r.get("condition", {})
        age = self.features.age
        if age <= 3:
            pct = cond_table.get("new_0_3", 0.10)
            self.adjustments.append(("New construction premium", bp * pct))
            self.explanation.append(f"Condition new (age {age}) +{pct*100:.2f}%")
        elif 4 <= age <= 10:
            pct = cond_table.get("slightly_used_4_10", 0.03)
            self.adjustments.append(("Slightly used bonus", bp * pct))
            self.explanation.append(f"Condition slightly used (age {age}) +{pct*100:.2f}%")
        elif 11 <= age <= 20:
            pct = cond_table.get("old_11_20", -0.08)
            self.adjustments.append(("Old property deduction", bp * pct))
            self.explanation.append(f"Condition old (age {age}) {pct*100:.2f}%")
        else:
            pct = cond_table.get("very_old_21_plus", -0.12)
            self.adjustments.append(("Very old property deduction", bp * pct))
            self.explanation.append(f"Condition very old (age {age}) {pct*100:.2f}%")

        # Construction quality
        quality_score = getattr(self.features, "construction_quality", 5)  # optional field
        q_factor = (quality_score - 5) * r.get("construction_quality_per_point", 0.02)
        self.adjustments.append(("Construction quality adjustment", bp * q_factor))
        self.explanation.append(f"Construction quality score {quality_score}: factor {q_factor:.3f}")

        # Parking
        if self.features.parking >= 1:
            pct = r.get("parking", {}).get("has_parking_pct", 0.03)
            self.adjustments.append(("Parking bonus", bp * pct))
            self.explanation.append(f"Parking available: +{pct*100:.2f}%")
        else:
            pct = r.get("parking", {}).get("no_parking_pct", -0.03)
            self.adjustments.append(("No parking deduction", bp * pct))
            self.explanation.append(f"No parking: {pct*100:.2f}%")

        # Street width (optional if field provided)
        street_cfg = r.get("street_width", {})
        wide_min = street_cfg.get("wide_min_ft", 40)
        narrow_max = street_cfg.get("narrow_max_ft", 20)
        if hasattr(self.features, "street_width_ft") and self.features.street_width_ft is not None:
            w = self.features.street_width_ft
            if w >= wide_min:
                pct = street_cfg.get("wide_percent", 0.05)
                self.adjustments.append(("Wide street premium", bp * pct))
                self.explanation.append(f"Wide street ({w} ft): +{pct*100:.2f}%")
            elif w <= narrow_max:
                pct = street_cfg.get("narrow_percent", -0.04)
                self.adjustments.append(("Narrow street deduction", bp * pct))
                self.explanation.append(f"Narrow street ({w} ft): {pct*100:.2f}%")

    def _apply_flat_rules(self, bp: float):
        r = self.rules.get("flat", {})
        # Floor
        fl = self.features.floor
        if fl == 0:
            pct = r.get("floor", {}).get("ground_pct", 0.05)
            self.adjustments.append(("Ground floor premium", bp * pct))
            self.explanation.append("Ground floor premium applied.")
        elif 1 <= fl <= 4:
            pct = r.get("floor", {}).get("1_4_pct", 0.0)
            # no adjustment; we still record explanation
            self.explanation.append("Normal floor (1-4): no floor adjustment.")
        elif 5 <= fl <= 8:
            pct = r.get("floor", {}).get("5_8_pct", -0.02)
            self.adjustments.append(("High floor deduction", bp * pct))
            self.explanation.append(f"High floor ({fl}) deduction.")
        else:  # 9+
            pct = r.get("floor", {}).get("9_plus_pct", -0.04)
            self.adjustments.append(("Very high floor deduction", bp * pct))
            self.explanation.append(f"Very high floor ({fl}) deduction.")

        # Building age
        age = self.features.age
        age_table = r.get("building_age", {})
        if age <= 5:
            pct = age_table.get("0_5", 0.06)
            self.adjustments.append(("New building premium", bp * pct))
            self.explanation.append("New building premium applied.")
        elif 6 <= age <= 15:
            self.explanation.append("Building age moderate: no age adjustment.")
        elif 16 <= age <= 25:
            pct = age_table.get("16_25", -0.08)
            self.adjustments.append(("Old building deduction", bp * pct))
            self.explanation.append("Old building deduction applied.")
        else:
            pct = age_table.get("25_plus", -0.12)
            self.adjustments.append(("Very old building deduction", bp * pct))
            self.explanation.append("Very old building deduction applied.")

        # Lift
        # We expect a boolean attribute 'lift_available'
        if getattr(self.features, "lift_available", True):
            pct = r.get("lift_available_pct", 0.04)
            self.adjustments.append(("Lift availability bonus", bp * pct))
            self.explanation.append("Lift available: bonus applied.")
        else:
            if fl >= 4:
                pct = r.get("no_lift_high_floor_penalty", -0.08)
                self.adjustments.append(("No-lift high floor penalty", bp * pct))
                self.explanation.append("No lift & high floor: penalty applied.")

        # Parking (flat-specific)
        p = r.get("parking", {})
        # Expect 'parking_type' attribute for flats: 'dedicated'|'shared'|'none'
        parking_type = getattr(self.features, "parking_type", None)
        if parking_type == "dedicated":
            self.adjustments.append(("Dedicated parking bonus", bp * p.get("dedicated_pct", 0.03)))
            self.explanation.append("Dedicated parking applied.")
        elif parking_type == "shared":
            self.adjustments.append(("Shared parking bonus", bp * p.get("shared_pct", 0.01)))
            self.explanation.append("Shared parking applied.")
        else:
            # fallback to count-based
            if self.features.parking >= 1:
                pct = p.get("dedicated_pct", 0.03)
                self.adjustments.append(("Parking bonus", bp * pct))
                self.explanation.append("Parking count suggests slot available.")
            else:
                self.adjustments.append(("No parking deduction", bp * p.get("none_pct", -0.03)))
                self.explanation.append("No parking deduction applied.")

        # Security & services
        sec_score = getattr(self.features, "security_score", 5)
        sec_max = r.get("security_max_effect", 0.05)
        sec_factor = (sec_score / 10.0) * sec_max
        self.adjustments.append(("Security/services adjustment", bp * sec_factor))
        self.explanation.append(f"Security factor {sec_factor:.4f}")

        # Bedrooms and bathrooms rules also apply for flats, similar to house.
        # Reuse bedroom/bathroom logic from house with adjusted percentages if desired.
        # For simplicity reuse house percentages
        house_rules = self.rules.get("house", {})
        # bedrooms
        std_bed = house_rules.get("standard_bedrooms", 3)
        if self.features.bedrooms > std_bed:
            extra = self.features.bedrooms - std_bed
            amount = bp * house_rules.get("bedroom_extra_pct", 0.03) * extra
            self.adjustments.append((f"Extra bedrooms ({extra})", amount))
            self.explanation.append("Extra bedrooms for flat applied.")
        # bathrooms
        std_bath = house_rules.get("standard_bathrooms", 2)
        if self.features.bathrooms > std_bath:
            extra = self.features.bathrooms - std_bath
            amount = bp * house_rules.get("bathroom_extra_pct", 0.02) * extra
            self.adjustments.append((f"Extra bathrooms ({extra})", amount))
            self.explanation.append("Extra bathrooms for flat applied.")

    def _apply_plot_rules(self, bp: float):
        r = self.rules.get("plot", {})
        # Position
        pos = self.features
        if pos.corner:
            pct = r.get("position", {}).get("corner_pct", 0.10)
            self.adjustments.append(("Corner plot premium", bp * pct))
            self.explanation.append("Corner plot premium applied.")
        if pos.facing_park:
            pct = r.get("position", {}).get("facing_park_pct", 0.08)
            self.adjustments.append(("Facing park premium", bp * pct))
            self.explanation.append("Facing park premium applied.")
        if pos.main_boulevard:
            pct = r.get("position", {}).get("main_boulevard_pct", 0.12)
            self.adjustments.append(("Main boulevard premium", bp * pct))
            self.explanation.append("Main boulevard premium applied.")
        if pos.dead_end:
            pct = r.get("position", {}).get("dead_end_pct", -0.05)
            self.adjustments.append(("Dead-end deduction", bp * pct))
            self.explanation.append("Dead-end deduction applied.")

        # Shape
        if pos.shape == "rectangular":
            pct = r.get("shape", {}).get("rectangular_pct", 0.03)
            self.adjustments.append(("Regular shape premium", bp * pct))
            self.explanation.append("Regular shape premium.")
        else:
            pct = r.get("shape", {}).get("odd_pct", -0.03)
            self.adjustments.append(("Odd shape deduction", bp * pct))
            self.explanation.append("Odd shape deduction.")

        # Front/Depth ratio
        if pos.front_width and pos.depth:
            ratio = pos.front_width / max(1.0, pos.depth)
            if ratio < r.get("front_depth_ratio_threshold", 0.5):
                pct = r.get("front_depth_penalty", -0.04)
                self.adjustments.append(("Poor front-to-depth ratio deduction", bp * pct))
                self.explanation.append("Front-depth ratio penalty applied.")

        # Soil
        soil = pos.soil or "mixed"
        soil_pct = r.get("soil", {}).get(f"{soil}_pct", 0.0)
        self.adjustments.append(("Soil condition adjustment", bp * soil_pct))
        self.explanation.append(f"Soil condition ({soil}) adjustment {soil_pct:.3f}")

        # Nearby commercial
        d = pos.nearby_commercial_distance_m
        if d is not None:
            if d <= 50:
                pct = r.get("nearby_commercial", {}).get("too_close_50m_penalty", -0.04)
                self.adjustments.append(("Too-close commercial noise deduction", bp * pct))
                self.explanation.append("Too-close commercial deduction.")
            elif d <= 200:
                pct = r.get("nearby_commercial", {}).get("within_200m_pct", 0.05)
                self.adjustments.append(("Nearby commercial premium", bp * pct))
                self.explanation.append("Nearby commercial premium.")

    # -------------------------
    # Final price calculation
    # -------------------------
    def calculate_final_price(self):
        """Sum base price and adjustments to get final price."""
        self.final_price = self.base_price + sum(amount for _, amount in self.adjustments)
        self.explanation.append(f"Final price computed: {self.final_price:,.0f}")
        return self.final_price

    # -------------------------
    # Rent estimation
    # -------------------------
    def estimate_rent(self):
        """Estimate monthly rent using rules or ML model if present."""
        assert self.features is not None, "Set features first."

        # Plots do not produce rent
        if self.features.property_type.lower() == "plot":
            self.base_rent = 0.0
            self.explanation.append("Rent skipped for plots.")
            return self.base_rent

        # Try ML model first (if available)
        ml_out = self.ml.predict("rent", self._features_for_model("rent"))
        if ml_out is not None:
            self.base_rent = ml_out
            self.explanation.append("Rent predicted by ML model.")
            return self.base_rent

        # Rule-based fallback
        multipliers = self.rules.get("rent", {}).get("multipliers", {})
        m = multipliers.get(self.features.property_type, None)
        if m is None:
            self.base_rent = 0.0
            return self.base_rent

        base_rent = self.final_price * m if self.final_price and self.final_price > 0 else self.base_price * m
        # Furnishing
        furnishing_type = getattr(self.features, "furnishing", "none")  # 'fully' | 'semi' | 'none'
        furn_pct = self.rules.get("rent", {}).get("furnishing", {}).get(furnishing_type, 0.0)
        rent_with_furn = base_rent * (1 + furn_pct)
        self.base_rent = rent_with_furn
        self.explanation.append(f"Rent estimated by rules: base {base_rent:,.0f} furnishing {furn_pct*100:.2f}%")
        return self.base_rent

    # -------------------------
    # ROI estimation
    # -------------------------
    def estimate_roi(self):
        """Estimate annual ROI (percentage) from rent and price."""
        # Try ML first
        ml_out = self.ml.predict("roi", self._features_for_model("roi"))
        if ml_out is not None:
            self.roi_value = ml_out
            self.explanation.append("ROI predicted by ML model.")
            return self.roi_value

        # Rule-based fallback
        rent = self.base_rent if self.base_rent is not None else self.estimate_rent()
        price = self.final_price if self.final_price and self.final_price > 0 else self.base_price
        if price <= 0:
            self.roi_value = 0.0
            return self.roi_value
        annual_rent = rent * 12
        self.roi_value = annual_rent / price
        # ROI as fraction (e.g. 0.05 = 5%)
        self.explanation.append(f"ROI: annual_rent {annual_rent:,.0f} / price {price:,.0f} -> {self.roi_value:.4f}")
        return self.roi_value

    # -------------------------
    # Risk scoring
    # -------------------------
    def compute_risk_score(self):
        """
        Compute a risk score 0-10 where higher is riskier, combining crime, legal, market volatility and development.
        Lower is better.
        """
        # try ML first
        ml_out = self.ml.predict("risk", self._features_for_model("risk"))
        if ml_out is not None:
            self.risk_score = ml_out
            self.explanation.append("Risk predicted by ML model.")
            return self.risk_score

        w = self.rules.get("risk", {}).get("weights", {})
        crime = getattr(self.features, "crime_score", 5.0)  # 1-10 where 10 is high crime
        legal = getattr(self.features, "legal_score", 1.0)  # 1 means clean; higher means worse
        market_vol = getattr(self.features, "demand_score", 5.0)
        development = getattr(self.features, "development_score", 5.0)

        # Note: normalize some inputs to 0-1 ranges as needed.
        crime_n = crime / 10.0
        legal_n = min(1.0, legal / 10.0)  # clamp
        market_n = 1.0 - (market_vol / 10.0)  # if high demand, lower market risk
        development_n = 1.0 - (development / 10.0)  # more development -> lower risk

        weights_sum = sum(w.values()) or 1.0
        composite = (
            crime_n * w.get("crime", 0.30) +
            legal_n * w.get("legal", 0.30) +
            market_n * w.get("market_volatility", 0.20) +
            development_n * w.get("development", 0.20)
        ) / weights_sum

        # Convert to 0-10 scale
        self.risk_score = float(round(composite * 10, 2))
        self.explanation.append(f"Risk composite {composite:.3f} -> score {self.risk_score}")
        return self.risk_score

    # -------------------------
    # Forecast / future price
    # -------------------------
    def forecast_future_price(self):
        """Forecast 1-year and 3-year price change percentages using rules or ML models."""
        fv_1 = self._features_for_model("future_1y")
        fv_3 = self._features_for_model("future_3y")
        ml_out_1 = self._safe_forecast_value(self.ml.predict("future_1y", fv_1))
        ml_out_3 = self._safe_forecast_value(self.ml.predict("future_3y", fv_3))
        if ml_out_1 is not None:
            self.forecast_1y = ml_out_1
            self.explanation.append("1-year forecast from ML model.")
        if ml_out_3 is not None:
            self.forecast_3y = ml_out_3
            self.explanation.append("3-year forecast from ML model.")

        # Rule-based baselines
        fg = self.rules.get("forecast", {}).get("growth_factors", {})
        demand_w = fg.get("demand_score_weight_pct", 0.003)
        dev_w = fg.get("development_score_weight_pct", 0.004)
        market_trend = fg.get("market_trend_pct", 0.005)
        uncertainty = self.rules.get("forecast", {}).get("uncertainty_scale", 0.15)
        dscore = getattr(self.features, "demand_score", 5.0)
        devscore = getattr(self.features, "development_score", 5.0)
        g1_rule = (dscore * demand_w) + (devscore * dev_w) + market_trend
        g3_rule = (g1_rule * 3) * (1 - uncertainty)

        # Prefer ML where available; otherwise use rule values directly
        if self.forecast_1y is None:
            self.forecast_1y = g1_rule
            self.explanation.append(f"1-year forecast (rules) {g1_rule:.4f}")
        if self.forecast_3y is None:
            self.forecast_3y = g3_rule
            self.explanation.append(f"3-year forecast (rules) {g3_rule:.4f}")

        return {"1y_pct": self.forecast_1y, "3y_pct": self.forecast_3y}

    def _safe_forecast_value(self, val: Optional[float]) -> Optional[float]:
        """
        Normalize and clamp ML forecast outputs to avoid runaway percentages.
        Expected input is a fraction (e.g., 0.08 = 8%). If models output whole
        percentages (e.g., 8 = 8%), we auto-scale by /100. Finally, clamp to a
        reasonable band.
        """
        if val is None:
            return None
        try:
            v = float(val)
        except Exception:
            return None
        # Auto-scale if clearly in whole-percent units
        if v > 1.0:
            v = v / 100.0
        # Clamp to [-20%, +50%] to avoid extreme outputs
        v = max(-0.20, min(0.50, v))
        return v

    # -------------------------
    # Helpers
    # -------------------------
    def _features_as_vector(self) -> Dict[str, Any]:
        """Convert Features dataclass to a flat dict for ML models and debugging."""
        if not self.features:
            return {}
        # Use only numeric / basic keys for ML vector; omit nested complex objects
        d = {
            "area": self.features.area,
            "property_type": self.features.property_type,
            "bedrooms": self.features.bedrooms,
            "bathrooms": self.features.bathrooms,
            "age": self.features.age,
            "parking": self.features.parking,
            "floor": self.features.floor,
            "amenities": self.features.amenities,
            "demand_score": self.features.demand_score,
            "development_score": self.features.development_score,
            "crime_score": self.features.crime_score,
            "legal_score": self.features.legal_score
        }
        # Additional optional features
        if self.features.front_width:
            d["front_width"] = self.features.front_width
        if self.features.depth:
            d["depth"] = self.features.depth
        if self.features.nearby_commercial_distance_m is not None:
            d["nearby_commercial_distance_m"] = self.features.nearby_commercial_distance_m
        return d

    def _features_for_model(self, key: str) -> Dict[str, Any]:
        """
        Build feature dictionaries aligned to the training schema of each ML model.
        Provides sensible defaults where the UI does not collect a value.
        """
        if not self.features:
            return {}

        f = self.features
        base = {
            "location": f.location,
            "property_type": f.property_type,
            "condition": getattr(f, "condition", "used"),
            "area": f.area,
            "bedrooms": f.bedrooms,
            "bathrooms": f.bathrooms,
            "age": f.age,
            "amenities_score": f.amenities,
            "demand_score": getattr(f, "demand_score", 5.0),
        }

        if key in {"price", "rent"}:
            return base

        if key == "roi":
            # Derive financial inputs from current estimates
            price_val = self.final_price or self.base_price or 0.0
            monthly_rent = self.base_rent if self.base_rent is not None else 0.0
            annual_rent = monthly_rent * 12
            base.update(
                {
                    "purchase_price": price_val,
                    "annual_rent": annual_rent,
                    "expenses": annual_rent * 0.15,
                    "occupancy_rate": getattr(f, "occupancy_rate", 0.95),
                    "market_appreciation_score": getattr(f, "development_score", 5.0),
                }
            )
            return base

        if key == "risk":
            base.update(
                {
                    "crime_index": getattr(f, "crime_score", 5.0),
                    "market_volatility": getattr(
                        f, "market_volatility", max(0.0, 10 - getattr(f, "demand_score", 5.0))
                    ),
                    "economic_stability": getattr(f, "development_score", 5.0),
                }
            )
            return base

        if key in {"future_1y", "future_3y"}:
            price_val = self.final_price or self.base_price or 0.0
            economic_index = (
                getattr(f, "economic_index", None)
                if getattr(f, "economic_index", None) is not None
                else (10 - self.risk_score if self.risk_score is not None else 5.0)
            )
            base.update(
                {
                    "current_price": price_val,
                    "development_index": getattr(f, "development_score", 5.0),
                    "economic_index": economic_index,
                    "market_trend": getattr(f, "market_trend", 0.01),
                }
            )
            return base

        return base

    # -------------------------
    # Full evaluate pipeline
    # -------------------------
    def evaluate_all(self, features: Features) -> Dict[str, Any]:
        """
        End-to-end evaluation:
        1. set features
        2. base price
        3. apply rules
        4. calculate final price
        5. estimate rent, roi, risk, forecast
        Returns a comprehensive result dict.
        """
        self.set_features(features)
        self.determine_base_price()
        self.apply_rules()
        self.calculate_final_price()
        rent = self.estimate_rent()
        roi = self.estimate_roi()
        risk = self.compute_risk_score()
        forecast = self.forecast_future_price()

        result = {
            "base_price": self.base_price,
            "adjustments": self.adjustments,
            "final_price": self.final_price,
            "rent_monthly": rent,
            "roi": roi,
            "risk_score": risk,
            "forecast_1y_pct": forecast["1y_pct"],
            "forecast_3y_pct": forecast["3y_pct"],
            "explanation": self.explanation,
            "property_type": self.features.property_type,
        }
        return result


# -------------------------
# Utility functions to save / load rules
# -------------------------
def save_rules_to_file(rules: Dict[str, Any], path: str = "rules.json"):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(rules, f, indent=2)
    print(f"[save_rules_to_file] Rules saved to {path}")


def load_rules_from_file(path: str = "rules.json") -> Dict[str, Any]:
    if not os.path.exists(path):
        save_rules_to_file(DEFAULT_RULES_JSON, path)
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# -------------------------
# Example usage (test)
# -------------------------
if __name__ == "__main__":
    # Ensure rules file exists
    rules_path = "rules.json"
    if not os.path.exists(rules_path):
        save_rules_to_file(DEFAULT_RULES_JSON, rules_path)

    rules = load_rules_from_file(rules_path)

    # Example: load ML models if available - here we pass none to use rule-based
    ml_paths = {
        # "price": "models/price_model.pkl",
        # "rent": "models/rent_model.pkl",
        # "roi": "models/roi_model.pkl",
        # "risk": "models/risk_model.pkl",
        # "future_1y": "models/future_1y.pkl",
        # "future_3y": "models/future_3y.pkl"
    }
    ml_manager = MLModelManager(ml_paths)

    # Create expert system
    expert = RealEstateExpertSystem(rules=rules, ml_manager=ml_manager)

    # Sample features for a house
    features_house = Features(
        location="wapda town",
        area=2000,
        property_type="house",
        bedrooms=4,
        bathrooms=3,
        condition="used",
        age=4,
        parking=2,
        floor=0,
        amenities=8,  # normalized to 1-10 scale
        demand_score=6,
        development_score=5,
        crime_score=3,
        legal_score=1
    )

    result = expert.evaluate_all(features_house)

    # Print a readable report
    print("\n" + "=" * 80)
    print("DETAILED ESTIMATION REPORT (Sample House)")
    print("=" * 80)
    print(f"Base price: Rs {result['base_price']:,.0f}")
    print("Adjustments:")
    for reason, amt in result["adjustments"]:
        sign = "+" if amt >= 0 else ""
        print(f"  {reason:<35} {sign}Rs {amt:,.0f}")
    print(f"\nFinal estimated price: Rs {result['final_price']:,.0f}")
    print(f"Estimated monthly rent: Rs {result['rent_monthly']:,.0f}")
    print(f"Estimated ROI (annual fraction): {result['roi']:.4f} -> {result['roi']*100:.2f}%")
    print(f"Risk score (0-10, higher is riskier): {result['risk_score']}")
    print(f"Forecast 1-year growth pct: {result['forecast_1y_pct']*100:.2f}%")
    print(f"Forecast 3-year growth pct: {result['forecast_3y_pct']*100:.2f}%")
    print("\nExplanation / Trace:")
    for line in result["explanation"]:
        print(" -", line)
    print("\n" + "=" * 80)
